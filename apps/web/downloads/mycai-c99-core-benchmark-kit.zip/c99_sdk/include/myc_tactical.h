#ifndef MYC_TACTICAL_H
#define MYC_TACTICAL_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ========================================================================= */
/* 1. SAHA BÖLGELERİ (18 PITCH ZONES - FIFA/UEFA STANDARDI)                 */
/* Saha 6 yatay koridor x 3 dikey bölgeye (toplam 18 bölge) ayrılmıştır.    */
/* ========================================================================= */
#define TACTICAL_ZONES_COUNT 18
#define ZONE_14_BOX_EDGE     14  /* Ceza sahası önü kilit hücum bölgesi      */

/* Taktiksel Direktif Tipleri */
#define DIRECTIVE_NONE            0x00
#define DIRECTIVE_PRESS_TRAP      0x01  /* Rakip oyuncuya şok pres tuzağı    */
#define DIRECTIVE_EXPLOIT_SPACE   0x02  /* Bek arkası boş koridora sızma     */
#define DIRECTIVE_DEEP_PENETRATION 0x03 /* Hatlar arası dikine derin pas     */
#define DIRECTIVE_SUBSTITUTION    0x04  /* Fizyolojik oyuncu değişikliği     */
#define DIRECTIVE_COMPACT_DEFENSE 0x05  /* Savunma hattını daraltma alarmı   */

/* ========================================================================= */
/* 2. MAÇ ÖNCESİ RAKİP ANALİZ DOSYASI (PRE-MATCH SCOUTING DOSSIER)          */
/* Rakibin geçmiş 5-10 maçının analitik özet modelleri                       */
/* ========================================================================= */
typedef struct {
    uint8_t  conceded_counter_attacks_pct; /* Geçiş hücumlarından yenen gol %*/
    uint8_t  conceded_set_pieces_pct;      /* Duran toplardan yenen gol %    */
    uint8_t  conceded_high_press_loss_pct; /* Kendi ceza sahası önü kayıptan */
    uint8_t  conceded_open_play_cross_pct; /* Yan ortalardan yenen gol %     */
    uint8_t  most_vulnerable_zone;         /* En çok pozisyon verilen bölge  */
} MycConcededGoalsProfile;

typedef struct {
    uint8_t  player_id;             /* Forma No                              */
    char     player_name[24];       /* Oyuncu Adı                            */
    char     position[8];           /* CB, LB, RB, DM, CM, ST vb.            */
    uint8_t  weak_foot;             /* 0: Sağ, 1: Sol                        */
    uint8_t  press_resistance_pct;  /* Baskı altında top tutma gücü (%0-100) */
    uint8_t  weak_foot_turnover_pct;/* Zayıf ayağına basılınca top kaybı %  */
    uint16_t avg_space_left_behind_m; /* Hücuma çıkınca arkasında bıraktığı alan (m) */
    uint8_t  fatigue_drop_minute;   /* Fiziksel düşüşün başladığı dakika     */
} MycPlayerScoutingProfile;

typedef struct {
    char                     team_name[24];
    MycConcededGoalsProfile  goals_profile;
    uint8_t                  scouted_player_count;
    MycPlayerScoutingProfile players[16];   /* 11 Asil + 5 kritik yedek      */
    uint8_t                  zone_vulnerability_score[TACTICAL_ZONES_COUNT]; /* 0-100 risk puanı */
} MycOpponentDossier;

/* ========================================================================= */
/* 3. CANLI MAÇ VERİSİ & FİZYOLOJİK TELEMETRİ                                */
/* ========================================================================= */
typedef struct {
    uint8_t  player_id;
    uint8_t  team_id;               /* 0: Kendi Takımımız, 1: Rakip          */
    uint16_t x_cm;                  /* Saha X koordinatı (0 - 10500 cm)      */
    uint16_t y_cm;                  /* Saha Y koordinatı (0 - 6800 cm)       */
    uint16_t speed_kmh_x10;
    uint8_t  fatigue_index_pct;     /* Anlık yorgunluk seviyesi (%0-100)     */
    uint8_t  recovery_time_sec;     /* Sprint sonrası toparlanma süresi (sn) */
    bool     has_ball;
    bool     facing_own_goal;       /* Sırtı rakip kaleye dönük mü?          */
} MycLivePlayerTelemetry;

typedef struct {
    uint32_t                match_minute;
    uint32_t                timestamp_ms;
    uint8_t                 possession_team_id;
    uint16_t                defense_line_x_cm;      /* Savunma hattı derinliği (cm) */
    uint16_t                midfield_line_x_cm;     /* Orta saha hattı derinliği    */
    uint16_t                line_distance_gap_cm;   /* Bloklar arası mesafe (cm)    */
    uint8_t                 telemetry_count;
    MycLivePlayerTelemetry  players[22];
} MycLiveMatchSnapshot;

/* ========================================================================= */
/* 4. ANLIK REÇETELİ TAKTİK DİREKTİFİ (PRESCRIPTIVE TACTICAL DIRECTIVE)      */
/* Teknik heyetin kulübedeki tabletine giden mikrosaniyelik karar            */
/* ========================================================================= */
typedef struct {
    uint8_t  directive_type;        /* DIRECTIVE_*                           */
    uint8_t  urgency_level;         /* 1: Düşük, 2: Orta, 3: KRİTİK          */
    char     title[48];             /* Direktif Başlığı                      */
    char     action_plan[128];      /* Net Eylem Planı                       */
    uint8_t  target_opponent_id;    /* Hedef alınan rakip oyuncu             */
    uint8_t  suggested_own_player_id; /* Görev verilen kendi oyuncumuz       */
    int16_t  metric_delta;          /* Hesaplanan mesafe/fark (cm veya %)    */
    uint32_t latency_ns;            /* Çekirdek karar süresi (nanosaniye)    */
} MycTacticalDirective;

typedef struct {
    bool     substitution_recommended;
    uint8_t  sub_out_player_id;     /* Çıkması önerilen kendi oyuncumuz      */
    char     player_name[24];
    uint8_t  fatigue_pct;
    char     reason[96];            /* Taktiksel ve fizyolojik gerekçe       */
    uint8_t  suggested_sub_in_id;   /* Girmesi önerilen yedek oyuncu         */
} MycSubstitutionAdvice;

/* Motor API Arayüzü */
void myc_tactical_init(void);
void myc_tactical_evaluate_directives(
    const MycOpponentDossier* dossier,
    const MycLiveMatchSnapshot* live_match,
    MycTacticalDirective* out_directive
);

void myc_tactical_check_substitution(
    const MycLiveMatchSnapshot* live_match,
    MycSubstitutionAdvice* out_sub_advice
);

#ifdef __cplusplus
}
#endif

#endif /* MYC_TACTICAL_H */
