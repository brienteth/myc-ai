#ifndef MYC_TELEMETRY_H
#define MYC_TELEMETRY_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ========================================================================= */
/* 1. STATUS VE ALARM KODLARI                                                */
/* ========================================================================= */
#define MYC_STATUS_OK             0x00
#define MYC_STATUS_WARN_THRESHOLD 0x01
#define MYC_STATUS_TRIP_CRITICAL  0x02
#define MYC_STATUS_THERMAL_RUNAWAY 0x03
#define MYC_STATUS_VISION_DEFECT  0x04
#define MYC_STATUS_SAFETY_BREACH  0x05

/* ========================================================================= */
/* 2. TEKİL ISI SENSÖRÜ (PT100 / Thermocouple / NTC / I2C / SPI)             */
/* Sabit noktalı aritmetik: 1/100 °C hassasiyet (örnek: 8525 = 85.25 °C)     */
/* ========================================================================= */
typedef struct {
    int32_t setpoint_c_x100;        /* Hedef çalışma sıcaklığı                 */
    int32_t warn_threshold_c_x100;  /* Uyarı eşiği                             */
    int32_t trip_threshold_c_x100;  /* Acil kesme (trip) eşiği                 */
    int32_t max_rate_of_rise_x100;  /* İzin verilen maks dT/dt (°C/saniye * 100)*/
    int32_t hysteresis_c_x100;      /* Röle salınım engelleme histerezisi      */
    int32_t ema_alpha_pct;          /* Dijital filtre katsayısı (0-100%)       */
} MycThermalConfig;

typedef struct {
    MycThermalConfig cfg;
    int32_t  current_ema_c_x100;     /* Filtrelenmiş anlık sıcaklık             */
    int32_t  previous_temp_c_x100;   /* Önceki örnek sıcaklığı                  */
    int32_t  rate_of_rise_c_per_sec; /* Anlık ısınma hızı (dT/dt)              */
    uint8_t  alarm_state;            /* NORMAL / WARN / TRIP / RUNAWAY          */
    bool     cooler_relay_active;    /* Soğutucu rölesi açık/kapalı             */
    bool     emergency_trip_active;  /* Acil durdurma devrede mi                */
    uint32_t sample_count;           /* İşlenen örnek adedi                     */
} MycThermalChannel;

typedef struct {
    uint8_t  status;
    int32_t  filtered_temp_c_x100;
    int32_t  rate_of_rise_x100;
    bool     action_trip_relay;
    bool     action_cooler_on;
    uint8_t  modbus_frame[8];        /* CRC16 dahil üretilen Modbus RTU paketi  */
} MycThermalDecision;

void myc_thermal_init(MycThermalChannel* ch, const MycThermalConfig* cfg);
void myc_thermal_process_sample(MycThermalChannel* ch, int32_t raw_temp_c_x100, uint32_t dt_ms, MycThermalDecision* out_dec);

/* ========================================================================= */
/* 3. TERMAL IZGARA / MATRİS KAMERASI (MLX90640: 32x24 = 768 piksel)        */
/* Statik RAM'de 768 adet int16_t (1.5 KB) tutulur. Sıfır malloc!            */
/* ========================================================================= */
#define MYC_THERMAL_GRID_COLS 32
#define MYC_THERMAL_GRID_ROWS 24
#define MYC_THERMAL_GRID_SIZE (MYC_THERMAL_GRID_COLS * MYC_THERMAL_GRID_ROWS)

typedef struct {
    int16_t  max_temp_c_x10;        /* Maksimum nokta sıcaklığı (0.1°C)        */
    int16_t  min_temp_c_x10;        /* Minimum nokta sıcaklığı                 */
    int16_t  avg_temp_c_x10;        /* Ortalama sıcaklık                       */
    uint8_t  hotspot_x;             /* En sıcak piksel X koordinatı            */
    uint8_t  hotspot_y;             /* En sıcak piksel Y koordinatı            */
    uint16_t cluster_pixels_above;  /* Eşik üzeri sıcak piksel küme büyüklüğü  */
    bool     hotspot_alarm;         /* Bölgesel aşırı ısınma / yangın alarmı   */
} MycGridAnalysisResult;

void myc_thermal_grid_analyze(
    const int16_t* grid_pixels_c_x10,
    int16_t hotspot_threshold_c_x10,
    MycGridAnalysisResult* out_result
);

/* ========================================================================= */
/* 4. AKILLI KAMERA / VİZYON TELEMETRİSİ (Edge Smart Camera Metadata)        */
/* Endüstriyel Smart Camera (Keyence/Cognex/OpenMV) NPU çıktısı telemetrisi  */
/* ========================================================================= */
typedef struct {
    uint32_t frame_seq;             /* Kamera kare no                          */
    uint16_t timestamp_ms;          /* Donanım zaman damgası                   */
    bool     defect_detected;       /* Hatalı parça tespit bayrağı             */
    uint8_t  defect_class_id;       /* Hata sınıfı (1: Çatlak, 2: Yanık vb)    */
    uint8_t  confidence_pct;        /* Yapay zeka tespit güven skoru (%0-100)  */
    bool     safety_zone_breach;    /* Tehlikeli alana insan/el ihlali         */
    uint16_t bbox_x;                /* Bounding box X                          */
    uint16_t bbox_y;                /* Bounding box Y                          */
    uint16_t bbox_w;                /* Bounding box Genişlik                   */
    uint16_t bbox_h;                /* Bounding box Yükseklik                  */
} MycVisionTelemetryFrame;

/* ========================================================================= */
/* 5. MULTI-SENSOR FUSION & DETERMINISTIC INTERLOCK                          */
/* Kamera telemetrisi + Isı sensörü -> Anlık Kesin Karar & Modbus RTU Çıkışı */
/* ========================================================================= */
typedef struct {
    uint8_t  decision_code;         /* 0: PASS, 1: REJECT_PART, 2: EMERGENCY_ESTOP */
    char     decision_reason[64];   /* Karar gerekçesi                         */
    bool     solenoid_reject_fire;  /* Pnömatik parça itici bobini tetikle     */
    bool     estop_safety_circuit;  /* Acil stop emniyet devresini aç (0V yap) */
    uint16_t target_modbus_reg;     /* Hedef PLC bobin/kayıt adresi            */
    uint16_t target_modbus_val;     /* Yazılacak değer                         */
    uint8_t  modbus_packet[8];      /* Gönderilecek standart Modbus RTU paketi */
    uint32_t latency_ns;            /* Karar motoru gecikmesi (nanosaniye)     */
} MycInterlockDecision;

void myc_evaluate_fusion_decision(
    const MycVisionTelemetryFrame* vision,
    const MycThermalChannel* thermal,
    MycInterlockDecision* out_decision
);

#ifdef __cplusplus
}
#endif

#endif /* MYC_TELEMETRY_H */
