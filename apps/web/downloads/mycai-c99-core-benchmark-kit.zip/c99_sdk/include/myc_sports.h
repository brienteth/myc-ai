#ifndef MYC_SPORTS_H
#define MYC_SPORTS_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ========================================================================= */
/* STANDART FUTBOL SAHASI KOORDİNATLARI (FIFA: 105m x 68m)                   */
/* Koordinatlar santimetre (cm) cinsinden tamsayıdır. (0-10500, 0-6800)      */
/* ========================================================================= */
#define PITCH_LENGTH_CM 10500
#define PITCH_WIDTH_CM  6800
#define GOAL_A_X        0
#define GOAL_B_X        10500
#define GOAL_Y_MIN      3034   /* 7.32m kale direkleri arası */
#define GOAL_Y_MAX      3766
#define MAX_PLAYERS_PER_TEAM 11
#define TOTAL_PLAYERS   22

/* Maç Olay Kodları (Instant Event Codes) */
#define EVENT_NONE            0x00
#define EVENT_PASS_INIT       0x01
#define EVENT_SHOT_ON_TARGET  0x02
#define EVENT_GOAL_SCORED     0x03
#define EVENT_OFFSIDE_FLAG    0x04
#define EVENT_BALL_OUT        0x05
#define EVENT_COUNTER_ATTACK  0x06

/* Oyuncu Pozisyon ve Telemetrisi (Yalnızca 8 Byte!) */
typedef struct {
    uint8_t  player_id;        /* Forma No                                  */
    uint8_t  team_id;          /* 0: Ev Sahibi, 1: Deplasman                */
    uint16_t x_cm;             /* Saha X koordinatı (0 - 10500 cm)          */
    uint16_t y_cm;             /* Saha Y koordinatı (0 - 6800 cm)           */
    uint16_t speed_kmh_x10;    /* Anlık koşu hızı (örnek: 285 = 28.5 km/h)  */
} __attribute__((packed)) MycPlayerState;

/* Top Dinamiği (Yalnızca 10 Byte!) */
typedef struct {
    uint16_t x_cm;
    uint16_t y_cm;
    uint16_t z_cm;             /* Topun yüksekliği                          */
    uint16_t speed_kmh_x10;    /* Topun hızı (örnek: 1120 = 112.0 km/h şut) */
    int8_t   last_touched_player;
    uint8_t  last_touched_team;
} __attribute__((packed)) MycBallState;

/* 1 Karelik Kompakt Maç Çerçevesi: 22 Oyuncu + Top = 186 Byte! */
typedef struct {
    uint32_t       frame_seq;
    uint32_t       timestamp_ms;
    MycBallState   ball;
    MycPlayerState players[TOTAL_PLAYERS];
} __attribute__((packed)) MycMatchFrame;

/* Gerçek Zamanlı Maç İstatistikleri (Canlı Kümülatif Veri) */
typedef struct {
    uint32_t possession_team_a_ms;   /* Topa sahip olma süresi (ms)         */
    uint32_t possession_team_b_ms;
    uint16_t total_passes_team_a;
    uint16_t total_passes_team_b;
    uint16_t total_shots_team_a;
    uint16_t total_shots_team_b;
    uint16_t goals_team_a;
    uint16_t goals_team_b;
    uint32_t distance_covered_cm_team_a; /* Takım toplam koşu mesafesi (cm)  */
    uint32_t distance_covered_cm_team_b;
    uint16_t offside_flags_raised;
} MycMatchStats;

/* Anlık Analiz ve Karar Sonucu (HUD / VAR Çıktısı) */
typedef struct {
    uint8_t  event_code;             /* EVENT_*                             */
    char     event_desc[64];         /* İnsan/Spiker okunabilir olay metni  */
    bool     offside_detected;       /* Anlık yarı-otomatik ofsayt çizgisi  */
    int8_t   offside_player_id;      /* Ofsayttaki oyuncu                   */
    int16_t  offside_margin_cm;      /* Ofsayt payı (+/- cm farkı)          */
    bool     goal_line_crossed;      /* Top çizgisini geçti mi (Goal-Line)  */
    uint16_t shot_speed_kmh_x10;     /* Şut hızı                            */
    float    expected_goal_xg;       /* Anlık Gol Beklentisi (xG: 0.00-1.0) */
    uint32_t latency_ns;             /* Karar alma süresi (nanosaniye)      */
} MycSportsAnalysisResult;

/* Motor Arayüzü */
void myc_sports_init(MycMatchStats* stats);
void myc_sports_process_frame(
    const MycMatchFrame* frame,
    MycMatchStats* stats,
    MycSportsAnalysisResult* out_result
);

#ifdef __cplusplus
}
#endif

#endif /* MYC_SPORTS_H */
