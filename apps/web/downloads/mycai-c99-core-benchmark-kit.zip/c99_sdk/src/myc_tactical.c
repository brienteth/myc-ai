#include "myc_tactical.h"
#include <string.h>
#include <time.h>
#include <stdio.h>

void myc_tactical_init(void) {
    /* Donanım seviyesi başlatma veya sayaç sıfırlama */
}

void myc_tactical_evaluate_directives(
    const MycOpponentDossier* dossier,
    const MycLiveMatchSnapshot* live_match,
    MycTacticalDirective* out_directive
) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    if (!out_directive) return;
    memset(out_directive, 0, sizeof(MycTacticalDirective));
    out_directive->directive_type = DIRECTIVE_NONE;
    strcpy(out_directive->title, "NOMİNAL_TAKTIK");
    strcpy(out_directive->action_plan, "Mevcut oyun planını koruyun. Saha yerleşimi dengeli.");

    if (!dossier || !live_match) {
        goto finish;
    }

    /* --------------------------------------------------------------------- */
    /* 1. EN YÜKSEK ÖNCELİK: KENDİ SAVUNMA HATTI KOPMA ALARMI                */
    /* Stoperlerimiz arası 15 metreyi aşarsa derhal acil uyarı verilir       */
    /* --------------------------------------------------------------------- */
    int cb1_idx = -1, cb2_idx = -1;
    for (int i = 0; i < live_match->telemetry_count; i++) {
        if (live_match->players[i].team_id == 0) { // Kendi takımımız
            if (cb1_idx == -1) cb1_idx = i;
            else if (cb2_idx == -1) { cb2_idx = i; break; }
        }
    }
    if (cb1_idx != -1 && cb2_idx != -1) {
        int dy = (int)live_match->players[cb1_idx].y_cm - (int)live_match->players[cb2_idx].y_cm;
        if (dy < 0) dy = -dy;
        if (dy > 1500) { // 15 metreden fazla açık
            out_directive->directive_type = DIRECTIVE_COMPACT_DEFENSE;
            out_directive->urgency_level = 3; // KRİTİK
            strcpy(out_directive->title, "🚨 SAVUNMA BLOĞU AÇILDI");
            snprintf(out_directive->action_plan, sizeof(out_directive->action_plan),
                     "Stoperler arası mesafe %.1f m oldu! Rakip santrfor araya koşu atıyor. Savunmayı daraltın.",
                     dy / 100.0f);
            out_directive->metric_delta = (int16_t)(dy / 100);
            goto finish;
        }
    }

    /* --------------------------------------------------------------------- */
    /* 2. PRES TUZAĞI (PRESS TRAP): RAKİP ZAYIF AYAKLI OYUNCU TOP ALDIĞINDA   */
    /* --------------------------------------------------------------------- */
    for (int i = 0; i < live_match->telemetry_count; i++) {
        const MycLivePlayerTelemetry* lp = &live_match->players[i];
        if (lp->team_id == 1 && lp->has_ball) { // Top rakip oyuncuda
            // Oyuncunun geçmiş maç zaafiyet profiline bak
            for (int j = 0; j < dossier->scouted_player_count; j++) {
                const MycPlayerScoutingProfile* sp = &dossier->players[j];
                if (sp->player_id == lp->player_id) {
                    // Eğer pres direnci düşükse (%60 altı) veya sırtı kaleye dönükse
                    if (sp->press_resistance_pct < 60 || lp->facing_own_goal) {
                        out_directive->directive_type = DIRECTIVE_PRESS_TRAP;
                        out_directive->urgency_level = 2; // YÜKSEK
                        out_directive->target_opponent_id = lp->player_id;
                        strcpy(out_directive->title, "⚡ ŞOK PRES TUZAĞI AKTİF");
                        snprintf(out_directive->action_plan, sizeof(out_directive->action_plan),
                                 "%s (#%d) topu aldı! %s ayağına yönlendirip 2 kişiyle şok pres yapın (Kayıp Riski: %%%d).",
                                 sp->player_name, sp->player_id,
                                 sp->weak_foot == 1 ? "Sol" : "Sağ",
                                 sp->weak_foot_turnover_pct);
                        out_directive->metric_delta = (int16_t)sp->weak_foot_turnover_pct;
                        goto finish;
                    }
                }
            }
        }
    }

    /* --------------------------------------------------------------------- */
    /* 3. BEK ARKASI BOŞ KORİDOR HÜCUMU (EXPLOIT SPACE BEHIND FULLBACK)      */
    /* Rakip bek 62 metreyi geçmiş ve hücuma çıkmışsa                        */
    /* --------------------------------------------------------------------- */
    for (int i = 0; i < live_match->telemetry_count; i++) {
        const MycLivePlayerTelemetry* lp = &live_match->players[i];
        if (lp->team_id == 1 && lp->x_cm > 6200) { // Rakip hücumda ileri çıkmış
            for (int j = 0; j < dossier->scouted_player_count; j++) {
                const MycPlayerScoutingProfile* sp = &dossier->players[j];
                if (sp->player_id == lp->player_id && 
                    (strstr(sp->position, "LB") || strstr(sp->position, "RB"))) {
                    
                    int space_behind_m = (int)(lp->x_cm / 100) - 30;
                    out_directive->directive_type = DIRECTIVE_EXPLOIT_SPACE;
                    out_directive->urgency_level = 2;
                    out_directive->target_opponent_id = lp->player_id;
                    strcpy(out_directive->title, "🎯 BEK ARKASI KORİDOR FIRSATI");
                    snprintf(out_directive->action_plan, sizeof(out_directive->action_plan),
                             "%s (#%d) 65m ileri çıktı! Arkasında %d metre kontrolsüz alan var. Kanat forvetini araya kaçırın.",
                             sp->player_name, sp->player_id, space_behind_m);
                    out_directive->metric_delta = (int16_t)space_behind_m;
                    goto finish;
                }
            }
        }
    }

    /* --------------------------------------------------------------------- */
    /* 4. HATLAR ARASI KOPMA VE DİKİNE DERİN PAS (ZONE 14 PENETRATION)       */
    /* --------------------------------------------------------------------- */
    if (live_match->line_distance_gap_cm > 2600) { // Bloklar arası > 26 metre
        out_directive->directive_type = DIRECTIVE_DEEP_PENETRATION;
        out_directive->urgency_level = 2;
        strcpy(out_directive->title, "🔥 RAKİP HATLAR ARASI KOPTU");
        snprintf(out_directive->action_plan, sizeof(out_directive->action_plan),
                 "Rakip stoperler ile orta saha arası %.1f metreye açıldı! 10 numara üzerinden Zone 14'e dikine pas yapın.",
                 live_match->line_distance_gap_cm / 100.0f);
        out_directive->metric_delta = (int16_t)(live_match->line_distance_gap_cm / 100);
        goto finish;
    }

finish:
    clock_gettime(CLOCK_MONOTONIC, &end);
    out_directive->latency_ns = (uint32_t)((end.tv_sec - start.tv_sec) * 1000000000L + (end.tv_nsec - start.tv_nsec));
}

/* ========================================================================= */
/* 5. BİLİMSEL OYUNCU DEĞİŞİKLİĞİ DANIŞMANI                                  */
/* ========================================================================= */
void myc_tactical_check_substitution(
    const MycLiveMatchSnapshot* live_match,
    MycSubstitutionAdvice* out_sub_advice
) {
    if (!live_match || !out_sub_advice) return;
    memset(out_sub_advice, 0, sizeof(MycSubstitutionAdvice));
    out_sub_advice->substitution_recommended = false;

    // 55. dakikadan sonra fiziksel telemetriyi tara
    if (live_match->match_minute < 55) return;

    for (int i = 0; i < live_match->telemetry_count; i++) {
        const MycLivePlayerTelemetry* p = &live_match->players[i];
        if (p->team_id == 0) { // Kendi oyuncumuz
            // Laktat ve toparlanma eşiği aşımı
            if (p->fatigue_index_pct >= 75 || p->recovery_time_sec >= 18) {
                out_sub_advice->substitution_recommended = true;
                out_sub_advice->sub_out_player_id = p->player_id;
                out_sub_advice->fatigue_pct = p->fatigue_index_pct;
                snprintf(out_sub_advice->player_name, sizeof(out_sub_advice->player_name), "Oyuncu #%d", p->player_id);
                snprintf(out_sub_advice->reason, sizeof(out_sub_advice->reason),
                         "Laktat yükü %%78'e ulaştı, toparlanma süresi %d sn. 65. dakikadan önce dinamik oyuncu ile değiştirilmeli.",
                         p->recovery_time_sec);
                out_sub_advice->suggested_sub_in_id = 18; // Hazır bekleyen taze yedek
                return;
            }
        }
    }
}
