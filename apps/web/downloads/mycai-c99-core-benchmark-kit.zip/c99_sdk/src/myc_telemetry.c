#include "myc_telemetry.h"
#include <string.h>
#include <time.h>

/* Modbus RTU CRC-16 Standard Lookup-Free Calculation (Minimal Flash) */
static uint16_t calc_crc16(const uint8_t *buf, uint16_t len) {
    uint16_t crc = 0xFFFF;
    for (uint16_t pos = 0; pos < len; pos++) {
        crc ^= (uint16_t)buf[pos];
        for (int i = 8; i != 0; i--) {
            if ((crc & 0x0001) != 0) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

static void pack_modbus_write_coil(uint8_t slave_id, uint16_t reg, uint16_t val, uint8_t* out_frame) {
    out_frame[0] = slave_id;
    out_frame[1] = 0x05; /* Write Single Coil */
    out_frame[2] = (uint8_t)(reg >> 8);
    out_frame[3] = (uint8_t)(reg & 0xFF);
    out_frame[4] = (uint8_t)(val >> 8);
    out_frame[5] = (uint8_t)(val & 0xFF);
    uint16_t crc = calc_crc16(out_frame, 6);
    out_frame[6] = (uint8_t)(crc & 0xFF);
    out_frame[7] = (uint8_t)(crc >> 8);
}

/* ========================================================================= */
/* 2. TEKİL ISI SENSÖRÜ İŞLEME                                               */
/* ========================================================================= */
void myc_thermal_init(MycThermalChannel* ch, const MycThermalConfig* cfg) {
    if (!ch || !cfg) return;
    memset(ch, 0, sizeof(MycThermalChannel));
    ch->cfg = *cfg;
    ch->alarm_state = MYC_STATUS_OK;
}

void myc_thermal_process_sample(
    MycThermalChannel* ch,
    int32_t raw_temp_c_x100,
    uint32_t dt_ms,
    MycThermalDecision* out_dec
) {
    if (!ch || !out_dec) return;
    memset(out_dec, 0, sizeof(MycThermalDecision));

    if (dt_ms == 0) dt_ms = 1; /* Sıfıra bölme koruması */

    /* 1. İlk örnek ise direkt başlat, değilse EMA filtresi uygula */
    if (ch->sample_count == 0) {
        ch->current_ema_c_x100 = raw_temp_c_x100;
        ch->previous_temp_c_x100 = raw_temp_c_x100;
        ch->rate_of_rise_c_per_sec = 0;
    } else {
        /* Sabit noktalı EMA filtresi: (alpha * raw + (100 - alpha) * prev) / 100 */
        int32_t alpha = ch->cfg.ema_alpha_pct;
        ch->current_ema_c_x100 = (alpha * raw_temp_c_x100 + (100 - alpha) * ch->current_ema_c_x100) / 100;

        /* Isınma hızı (dT/dt) hesaplama (°C / saniye * 100) */
        int32_t delta_t = ch->current_ema_c_x100 - ch->previous_temp_c_x100;
        ch->rate_of_rise_c_per_sec = (delta_t * 1000) / (int32_t)dt_ms;
        ch->previous_temp_c_x100 = ch->current_ema_c_x100;
    }
    ch->sample_count++;

    /* 2. Karar Matrisi & Eşik Denetimleri */
    out_dec->filtered_temp_c_x100 = ch->current_ema_c_x100;
    out_dec->rate_of_rise_x100 = ch->rate_of_rise_c_per_sec;

    /* A. Termal Kaçak (Thermal Runaway) Koruması: Ani aşırı hızlı ısınma */
    if (ch->cfg.max_rate_of_rise_x100 > 0 && 
        ch->rate_of_rise_c_per_sec > ch->cfg.max_rate_of_rise_x100) {
        ch->alarm_state = MYC_STATUS_THERMAL_RUNAWAY;
        ch->emergency_trip_active = true;
        ch->cooler_relay_active = true;
        out_dec->status = MYC_STATUS_THERMAL_RUNAWAY;
        out_dec->action_trip_relay = true;
        out_dec->action_cooler_on = true;
        pack_modbus_write_coil(0x01, 0x0090, 0xFF00, out_dec->modbus_frame); /* Acil Tripping Rölesi */
        return;
    }

    /* B. Kritik Kesme (Critical Trip) Eşiği */
    if (ch->current_ema_c_x100 >= ch->cfg.trip_threshold_c_x100) {
        ch->alarm_state = MYC_STATUS_TRIP_CRITICAL;
        ch->emergency_trip_active = true;
        ch->cooler_relay_active = true;
        out_dec->status = MYC_STATUS_TRIP_CRITICAL;
        out_dec->action_trip_relay = true;
        out_dec->action_cooler_on = true;
        pack_modbus_write_coil(0x01, 0x0090, 0xFF00, out_dec->modbus_frame);
        return;
    }

    /* C. Uyarı & Soğutucu Histerezis Kontrolü */
    if (ch->current_ema_c_x100 >= ch->cfg.warn_threshold_c_x100) {
        ch->cooler_relay_active = true;
        ch->alarm_state = MYC_STATUS_WARN_THRESHOLD;
        out_dec->status = MYC_STATUS_WARN_THRESHOLD;
        out_dec->action_cooler_on = true;
        pack_modbus_write_coil(0x01, 0x0010, 0xFF00, out_dec->modbus_frame); /* Soğutucu Fan/Pompa ON */
    } else if (ch->cooler_relay_active && 
               ch->current_ema_c_x100 < (ch->cfg.warn_threshold_c_x100 - ch->cfg.hysteresis_c_x100)) {
        /* Sıcaklık histerezis eşiğinin altına düşerse soğutucu kapatılır (röle çırpınması engellenir) */
        ch->cooler_relay_active = false;
        ch->alarm_state = MYC_STATUS_OK;
        out_dec->status = MYC_STATUS_OK;
        out_dec->action_cooler_on = false;
        pack_modbus_write_coil(0x01, 0x0010, 0x0000, out_dec->modbus_frame); /* Soğutucu OFF */
    } else {
        out_dec->status = ch->alarm_state;
        out_dec->action_cooler_on = ch->cooler_relay_active;
    }
}

/* ========================================================================= */
/* 3. TERMAL IZGARA / KAMERA ANALİZİ (MLX90640: 32x24 = 768 piksel)          */
/* 1.5 KB bellek taraması, maksimum sıcaklık ve hotspot koordinat tespiti    */
/* ========================================================================= */
void myc_thermal_grid_analyze(
    const int16_t* grid_pixels_c_x10,
    int16_t hotspot_threshold_c_x10,
    MycGridAnalysisResult* out_result
) {
    if (!grid_pixels_c_x10 || !out_result) return;
    memset(out_result, 0, sizeof(MycGridAnalysisResult));

    int16_t max_val = grid_pixels_c_x10[0];
    int16_t min_val = grid_pixels_c_x10[0];
    int32_t sum_val = 0;
    uint8_t hot_x = 0;
    uint8_t hot_y = 0;
    uint16_t above_count = 0;

    for (int y = 0; y < MYC_THERMAL_GRID_ROWS; y++) {
        int row_offset = y * MYC_THERMAL_GRID_COLS;
        for (int x = 0; x < MYC_THERMAL_GRID_COLS; x++) {
            int16_t val = grid_pixels_c_x10[row_offset + x];
            sum_val += val;

            if (val > max_val) {
                max_val = val;
                hot_x = (uint8_t)x;
                hot_y = (uint8_t)y;
            }
            if (val < min_val) {
                min_val = val;
            }
            if (val >= hotspot_threshold_c_x10) {
                above_count++;
            }
        }
    }

    out_result->max_temp_c_x10 = max_val;
    out_result->min_temp_c_x10 = min_val;
    out_result->avg_temp_c_x10 = (int16_t)(sum_val / MYC_THERMAL_GRID_SIZE);
    out_result->hotspot_x = hot_x;
    out_result->hotspot_y = hot_y;
    out_result->cluster_pixels_above = above_count;
    out_result->hotspot_alarm = (max_val >= hotspot_threshold_c_x10);
}

/* ========================================================================= */
/* 4. MULTI-SENSOR FUSION & DETERMINISTIC INTERLOCK                          */
/* Kamera telemetrisi + Isı sensörü -> Anlık Kesin Karar & Modbus RTU Çıkışı */
/* ========================================================================= */
void myc_evaluate_fusion_decision(
    const MycVisionTelemetryFrame* vision,
    const MycThermalChannel* thermal,
    MycInterlockDecision* out_decision
) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    if (!out_decision) return;
    memset(out_decision, 0, sizeof(MycInterlockDecision));

    /* 1. En Yüksek Öncelik: Emniyet İhlali (Safety Barrier Breach) */
    if (vision && vision->safety_zone_breach) {
        out_decision->decision_code = 2; /* EMERGENCY_ESTOP */
        strcpy(out_decision->decision_reason, "SAFETY_ZONE_BREACH (Human/Obstacle Intrusion)");
        out_decision->estop_safety_circuit = true;
        out_decision->target_modbus_reg = 0x0099; /* Donanım E-Stop Hattı */
        out_decision->target_modbus_val = 0xFF00;
        pack_modbus_write_coil(0x01, out_decision->target_modbus_reg, out_decision->target_modbus_val, out_decision->modbus_packet);
        
        clock_gettime(CLOCK_MONOTONIC, &end);
        out_decision->latency_ns = (uint32_t)((end.tv_sec - start.tv_sec) * 1000000000L + (end.tv_nsec - start.tv_nsec));
        return;
    }

    /* 2. İkinci Öncelik: Termal Kaçak veya Kritik Aşırı Isınma */
    if (thermal && (thermal->alarm_state == MYC_STATUS_TRIP_CRITICAL || 
                    thermal->alarm_state == MYC_STATUS_THERMAL_RUNAWAY)) {
        out_decision->decision_code = 2; /* EMERGENCY_ESTOP */
        strcpy(out_decision->decision_reason, "CRITICAL_THERMAL_TRIP (Thermal Runaway / Overheat)");
        out_decision->estop_safety_circuit = true;
        out_decision->target_modbus_reg = 0x0090; /* Acil Güç Kesici */
        out_decision->target_modbus_val = 0xFF00;
        pack_modbus_write_coil(0x01, out_decision->target_modbus_reg, out_decision->target_modbus_val, out_decision->modbus_packet);

        clock_gettime(CLOCK_MONOTONIC, &end);
        out_decision->latency_ns = (uint32_t)((end.tv_sec - start.tv_sec) * 1000000000L + (end.tv_nsec - start.tv_nsec));
        return;
    }

    /* 3. Üçüncü Öncelik: Kalite Kontrol Vizyon Hatası (Defect Rejection) */
    if (vision && vision->defect_detected && vision->confidence_pct >= 80) {
        out_decision->decision_code = 1; /* REJECT_PART */
        strcpy(out_decision->decision_reason, "VISION_DEFECT_DETECTED (Pneumatic Rejection)");
        out_decision->solenoid_reject_fire = true;
        out_decision->target_modbus_reg = 0x0050; /* Pnömatik İtici Bobin */
        out_decision->target_modbus_val = 0xFF00;
        pack_modbus_write_coil(0x01, out_decision->target_modbus_reg, out_decision->target_modbus_val, out_decision->modbus_packet);

        clock_gettime(CLOCK_MONOTONIC, &end);
        out_decision->latency_ns = (uint32_t)((end.tv_sec - start.tv_sec) * 1000000000L + (end.tv_nsec - start.tv_nsec));
        return;
    }

    /* 4. Normal Çalışma Koşulu (Nominal Pass) */
    out_decision->decision_code = 0; /* PASS */
    strcpy(out_decision->decision_reason, "NOMINAL_OPERATION");
    out_decision->target_modbus_reg = 0x0000;
    out_decision->target_modbus_val = 0x0000;

    clock_gettime(CLOCK_MONOTONIC, &end);
    out_decision->latency_ns = (uint32_t)((end.tv_sec - start.tv_sec) * 1000000000L + (end.tv_nsec - start.tv_nsec));
}
