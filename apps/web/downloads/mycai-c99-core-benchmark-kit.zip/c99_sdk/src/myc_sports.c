#include "myc_sports.h"
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdio.h>

void myc_sports_init(MycMatchStats* stats) {
    if (!stats) return;
    memset(stats, 0, sizeof(MycMatchStats));
}

void myc_sports_process_frame(
    const MycMatchFrame* frame,
    MycMatchStats* stats,
    MycSportsAnalysisResult* out_result
) {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    if (!frame || !out_result) return;
    memset(out_result, 0, sizeof(MycSportsAnalysisResult));
    out_result->event_code = EVENT_NONE;
    strcpy(out_result->event_desc, "PLAY_CONTINUES");

    /* --------------------------------------------------------------------- */
    /* 1. GOL ÇİZGİSİ KONTROLÜ (Otomatik Goal-Line Teknolojisi)             */
    /* --------------------------------------------------------------------- */
    if (frame->ball.y_cm >= GOAL_Y_MIN && frame->ball.y_cm <= GOAL_Y_MAX) {
        if (frame->ball.x_cm >= GOAL_B_X) {
            out_result->goal_line_crossed = true;
            out_result->event_code = EVENT_GOAL_SCORED;
            strcpy(out_result->event_desc, "⚽ GOL! Top B Kalesinin Çizgisini Geçti (Takım A Skoru)");
            if (stats) stats->goals_team_a++;
            goto finish;
        } else if (frame->ball.x_cm <= GOAL_A_X) {
            out_result->goal_line_crossed = true;
            out_result->event_code = EVENT_GOAL_SCORED;
            strcpy(out_result->event_desc, "⚽ GOL! Top A Kalesinin Çizgisini Geçti (Takım B Skoru)");
            if (stats) stats->goals_team_b++;
            goto finish;
        }
    }

    /* --------------------------------------------------------------------- */
    /* 2. ŞUT VE xG (GOL BEKLENTİSİ) ANALİZİ                                 */
    /* --------------------------------------------------------------------- */
    out_result->shot_speed_kmh_x10 = frame->ball.speed_kmh_x10;
    if (frame->ball.speed_kmh_x10 >= 700) { /* 70 km/h üzeri sert şut */
        if (frame->ball.last_touched_team == 0 && frame->ball.x_cm > 8000) {
            out_result->event_code = EVENT_SHOT_ON_TARGET;
            float dist_m = (GOAL_B_X - frame->ball.x_cm) / 100.0f;
            float xg = 1.0f / (1.0f + (dist_m * 0.15f));
            if (xg > 0.95f) xg = 0.95f;
            if (xg < 0.02f) xg = 0.02f;
            out_result->expected_goal_xg = xg;
            snprintf(out_result->event_desc, sizeof(out_result->event_desc),
                     "🔥 ŞUT! Hız: %.1f km/h | xG: %.2f (Takım A)",
                     frame->ball.speed_kmh_x10 / 10.0f, xg);
            if (stats) stats->total_shots_team_a++;
            goto finish;
        }
    }

    /* --------------------------------------------------------------------- */
    /* 3. YARI-OTOMATİK OFSAYT ÇİZGİSİ ANALİZİ                              */
    /* --------------------------------------------------------------------- */
    if (frame->ball.last_touched_team == 0) {
        uint16_t max_attacker_x = 0;
        int8_t   farthest_attacker_id = -1;

        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            if (frame->players[i].team_id == 0) {
                if (frame->players[i].x_cm > max_attacker_x) {
                    max_attacker_x = frame->players[i].x_cm;
                    farthest_attacker_id = frame->players[i].player_id;
                }
            }
        }

        uint16_t def_1 = 0, def_2 = 0;
        for (int i = 0; i < TOTAL_PLAYERS; i++) {
            if (frame->players[i].team_id == 1) {
                uint16_t px = frame->players[i].x_cm;
                if (px > def_1) {
                    def_2 = def_1;
                    def_1 = px;
                } else if (px > def_2) {
                    def_2 = px;
                }
            }
        }

        if (max_attacker_x > 5250 && max_attacker_x > def_2) {
            out_result->offside_detected = true;
            out_result->offside_player_id = farthest_attacker_id;
            out_result->offside_margin_cm = (int16_t)(max_attacker_x - def_2);
            out_result->event_code = EVENT_OFFSIDE_FLAG;
            snprintf(out_result->event_desc, sizeof(out_result->event_desc),
                     "🚩 OFSAYT TESPİT EDİLDİ! Oyuncu #%d (+%d cm önde)",
                     farthest_attacker_id, out_result->offside_margin_cm);
            if (stats) stats->offside_flags_raised++;
            goto finish;
        }
    }

    /* --------------------------------------------------------------------- */
    /* 4. TOPA SAHİP OLMA BİRİKİMİ                                           */
    /* --------------------------------------------------------------------- */
    if (stats) {
        if (frame->ball.last_touched_team == 0) {
            stats->possession_team_a_ms += 40;
        } else {
            stats->possession_team_b_ms += 40;
        }
    }

finish:
    clock_gettime(CLOCK_MONOTONIC, &end);
    out_result->latency_ns = (uint32_t)((end.tv_sec - start.tv_sec) * 1000000000L + (end.tv_nsec - start.tv_nsec));
}
