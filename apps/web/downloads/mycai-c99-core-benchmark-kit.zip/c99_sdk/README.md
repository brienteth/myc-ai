# MYCA C99 Cognitive Inference SDK
### Microcontroller-Native Deterministic Intelligence Runtime

**Official Repository & Evaluation Kit**  
* **Contact & Alliances:** enterprise@mycai.pro  
* **Website:** https://mycai.pro  
* **Target Platforms:** Microcontrollers (STM32, NXP, Microchip, ESP32, RP2040/RP2350), RTOS (FreeRTOS, Zephyr, ThreadX), Industrial PLCs, SCADA IPCs.

---

## 💎 Technical Overview

The **MYCA C99 Cognitive Inference SDK** is an ultra-compact, dependency-free ANSI C99 runtime engineered for mission-critical, air-gapped embedded environments.

* **Pure ANSI C99 (.c/.h):** Zero external runtime dependencies. No Python, Node.js, or Linux required.
* **Deterministic Latency:** 4.2 µs average execution time in our current benchmark workload.
* **Ultra-Low Memory Footprint:** <64 KB RAM target (<2 KB static stack/BSS, zero heap/malloc).
* **100% Air-Gapped & Sovereign:** Zero telemetry, zero cloud APIs, zero external inference costs.

---

## 🚀 Quick Start & Benchmarking

### 1. Build and Run the 10,000-Iteration Benchmark
```bash
make run
```

### 2. Compile as Static Library
```bash
make lib
# Outputs libmyca_core.a for linking into your firmware or RTOS project
```

---

## 📞 Technical Evaluation & Pilot Support

To arrange a 15-minute technical benchmark on your actual target hardware, or to request custom neural/logic quantization for your MCU/PLC workload:
* **Email:** enterprise@mycai.pro
* **Web:** https://mycai.pro
