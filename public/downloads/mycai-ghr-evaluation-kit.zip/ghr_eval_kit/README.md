# MYCA GHR Coherent Resonance — Independent Evaluation Kit

Welcome to the independent evaluation test harness for **MYCA GHR (Coherent Resonance Filter)**.

This harness is designed to verify the following mission-critical claims under extreme noise conditions:
- **-12 dB to -20 dB SNR Weak Signal Detection:** Locks onto target resonance frequencies submerged deep below the noise floor.
- **Zero False Alarms:** 0.0% false alarm rate in pure noise intervals (where standard energy and bandpass filters fail with 3,000+ false alarms).
- **Sub-Microsecond O(1) Latency:** ~80-100 ns execution time per sample.
- **Ultra-Compact Footprint:** 564 bytes static RAM, zero dynamic allocations (`0 malloc / 0 heap`).
- **30x Electrical Arc / EMI Surge Protection:** Instantaneous non-linear clamping of severe contactor/inverter spikes.

---

## Quick Start (Compile & Run in 5 Seconds)

### Option 1: Using Make (Recommended for C/Embedded Engineers)
```bash
make run
```
Or manually with GCC / Clang:
```bash
gcc -O3 -std=c99 myc_ghr_eval.c -lm -o ghr_eval
./ghr_eval
```

### Option 2: Using Python (Zero Dependencies)
```bash
python3 run_benchmark.py
```
*(Automatically compiles native C99 binary if a compiler is found, or executes the mathematical model directly).*

---

## Directory Structure
```text
ghr_eval_kit/
├── Makefile             # C99 build configuration
├── myc_ghr_eval.c       # Clean ANSI C99 evaluation benchmark source
├── run_benchmark.py     # Cross-platform runner script
├── run_benchmark.sh     # Quick terminal launcher
├── include/
│   └── myc_ghr_eval.h   # C API header definition
└── README.md            # This documentation
```

---

## Contact & Integration
For licensing, hardware customization, or full architecture integration:
- Web: [https://mycai.pro](https://mycai.pro)
- Email: [partnerships@mycai.pro](mailto:partnerships@mycai.pro)
