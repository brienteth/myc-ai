# MYCA GHR Coherent Resonance Evaluation Kit (v1.0)
**Proprietary Micro-Firmware for Weak-Signal Extraction in Extreme Noise (-12 dB to -20 dB SNR)**

---

## 🚀 Overview
The **MYCA GHR Coherent Resonance** engine is a deterministic $O(1)$ lock-in demodulation firmware specifically engineered for:
1. **Industrial Predictive Maintenance (PdM):** Extracting bearing fault vibration frequencies (BPFO, BPFI, gear mesh) submerged under 4x–10x heavy plant noise.
2. **Extreme Electrical EMI & Arc Suppression:** Clamping up to 30x amplitude relay/contactor spark spikes without sensor desensitization or numeric overflow.
3. **Ultra-Low Latency Telemetry:** 50–80 nanosecond deterministic execution per sample on Cortex-M4/M7, RISC-V, and industrial DSPs.
4. **Zero Malloc Footprint:** 564 Bytes static RAM allocation, suitable for bare-metal edge sensors.

---

## 📦 What is in this Evaluation Kit?
This package contains a pre-compiled, standalone evaluation runner designed to demonstrate performance directly on your local workstation without requiring full SDK deployment:

- `bin/ghr_eval_runner`: Pre-compiled native evaluation binary (Universal 64-bit for macOS ARM64 & Intel x86_64).
- `bin/ghr_eval_runner.py`: Pure Python evaluation runner (cross-platform for Linux, Windows, macOS; zero external dependencies).
- `include/myc_ghr_eval.h`: Public API definition and evaluation structures.
- `run_benchmark.sh`: One-click automated benchmark execution script (Linux & macOS).
- `run_benchmark.bat`: One-click automated benchmark execution script (Windows).

> *Note:* The full mathematical invariant kernel, bare-metal C99 source code, and multi-channel resonator bank are proprietary intellectual property of MYCAI.PRO and are licensed exclusively for enterprise OEM integrations.

---

## ⚡ Quick Start

### On Linux or macOS:
```bash
chmod +x run_benchmark.sh
./run_benchmark.sh
```

### On Windows:
Double-click `run_benchmark.bat` or run:
```cmd
python bin\ghr_eval_runner.py
```

---

## 📊 Expected Output Metrics
- **Input Noise Level:** -12 dB to -20 dB SNR (Signal is submerged in 4x–10x noise)
- **Extreme Arc Spikes:** 40 electrical sparks (30x amplitude) safely clamped
- **Standard Baseline Filter:** FAILED (>2000 false alarms under heavy noise)
- **MYCA GHR False Alarm Rate:** 0.0% (Pure noise periods completely suppressed)
- **Deterministic Latency:** ~80 ns per sample (bare-metal compiled)
- **Memory Footprint:** 564 Bytes static RAM (0 Malloc / 0 Heap)

---

## 💼 Enterprise Licensing & Microcontroller Integration
To evaluate MYCA GHR Coherent Resonance on your target microcontroller (STM32, NXP, TI, ESP32, FPGA) or test against your proprietary raw vibration/acoustic sensor recordings:
- **Email:** partnerships@mycai.pro | enterprise@mycai.pro
- **Website:** https://mycai.pro
