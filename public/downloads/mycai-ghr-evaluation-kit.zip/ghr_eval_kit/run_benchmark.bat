@echo off
rem ==============================================================================
rem MYCA GHR Coherent Resonance Micro-Firmware Benchmark Runner (Windows)
rem (c) 2026 MYCAI.PRO — All Rights Reserved. Confidential Evaluation Kit.
rem ==============================================================================

cd /d "%~dp0"

echo =================================================================
echo   MYCA GHR Coherent Resonance Micro-Firmware Benchmark
echo   (c) 2026 MYCAI.PRO — Enterprise Evaluation Harness
echo =================================================================

where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    python bin\ghr_eval_runner.py
    goto end
)

where python3 >nul 2>nul
if %ERRORLEVEL% equ 0 (
    python3 bin\ghr_eval_runner.py
    goto end
)

echo [ERROR] Python was not found in PATH. Please install Python 3 to run this benchmark on Windows.
:end
pause
