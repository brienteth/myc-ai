#!/usr/bin/env bash
# ==============================================================================
# MYCA GHR Coherent Resonance Micro-Firmware Benchmark Runner
# (c) 2026 MYCAI.PRO — All Rights Reserved. Confidential Evaluation Kit.
# ==============================================================================

set -e

# Resolve script directory dynamically
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "================================================================="
echo "  MYCA GHR Coherent Resonance Micro-Firmware Benchmark"
echo "  (c) 2026 MYCAI.PRO — Enterprise Evaluation Harness"
echo "================================================================="

OS="$(uname -s 2>/dev/null || echo 'Unknown')"

if [ "$OS" = "Darwin" ] && [ -f "./bin/ghr_eval_runner" ]; then
    chmod +x ./bin/ghr_eval_runner 2>/dev/null || true
    ./bin/ghr_eval_runner
elif command -v python3 >/dev/null 2>&1; then
    python3 ./bin/ghr_eval_runner.py
elif command -v python >/dev/null 2>&1; then
    python ./bin/ghr_eval_runner.py
elif [ -f "./bin/ghr_eval_runner" ]; then
    chmod +x ./bin/ghr_eval_runner 2>/dev/null || true
    ./bin/ghr_eval_runner
else
    echo "[ERROR] No compatible execution runtime found (requires Python 3.x or compatible host)."
    exit 1
fi
