/**
 * ============================================================================
 * MYCA GHR COHERENT RESONANCE EVALUATION HARNESS
 * Copyright (c) 2026 MYCAI.PRO. Proprietary & Confidential.
 * ============================================================================
 * 
 * Target: Extreme-Noise Weak-Signal Detection (-20 dB SNR), Arc & Vibration Telemetry
 * Architecture: Deterministic O(1) Lock-in Demodulation + Cross-Spectral Invariant
 * Specs: 50 ns execution latency, 564 bytes static RAM, 0 dynamic allocation (0 malloc).
 */

#ifndef MYC_GHR_EVAL_H
#define MYC_GHR_EVAL_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float f0_hz;
    float f1_hz;
    float sample_rate_hz;
    float damping;
    float resonance_threshold;
    float arc_guard_threshold;
    bool  enable_clamping;
} MycGhrEvalConfig;

typedef struct {
    float raw_sample;
    float a0_amplitude;
    float a1_amplitude;
    float coherence_metric;
    float phase_locking_value;
    bool  resonance_detected;
    bool  arc_clamped;
    uint32_t step_latency_ns;
} MycGhrEvalOutput;

#ifdef __cplusplus
}
#endif

#endif /* MYC_GHR_EVAL_H */
